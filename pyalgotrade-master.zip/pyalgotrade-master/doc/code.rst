Documentation for the code
==========================

Contents:

.. toctree::
    :maxdepth: 2

    bar
    dataseries
    feed
    barfeed
    technical
    broker
    strategy
    stratanalyzer
    plotter
    optimizer
    marketsession

