twitter -- Twitter feed reference
=================================

Feed
----

.. automodule:: pyalgotrade.twitter.feed
    :members: TwitterFeed
    :show-inheritance:

