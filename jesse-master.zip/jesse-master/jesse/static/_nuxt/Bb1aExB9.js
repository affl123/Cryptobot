import{a as r,B as t}from"./Jjv4biHX.js";const s={};function a(e,n){return t(e.$slots,"default")}const c=r(s,[["render",a]]);export{c as default};
