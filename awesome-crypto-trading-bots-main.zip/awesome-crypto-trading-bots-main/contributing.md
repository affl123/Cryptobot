# Contributing

We are looking for tools and resources about crypto trading bots. Every tools must be open source. Everything resources must be free. 

To add an item, fork the list, edit README.md and create a pull request.
