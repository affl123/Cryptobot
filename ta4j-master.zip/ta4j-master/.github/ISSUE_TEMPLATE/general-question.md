---
name: General question
about: A general question about how to use ta4j
title: ''
labels: question
assignees: ''

---

**I have checked existing issues and wiki**
- [ ] I could not find similar [issues](https://github.com/ta4j/ta4j/issues?utf8=%E2%9C%93&q=)
- [ ] I could not find a solution in the [wiki](https://ta4j.github.io/ta4j-wiki/) or [faq section](https://ta4j.github.io/ta4j-wiki/FAQ.html)

If possible provide a **[minimal working example](https://stackoverflow.com/help/mcve)**!
